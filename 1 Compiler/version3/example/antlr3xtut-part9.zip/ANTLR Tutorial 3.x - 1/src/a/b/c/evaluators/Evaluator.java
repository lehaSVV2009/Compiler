package a.b.c.evaluators;

public interface Evaluator {
	int evaluate();
	String toTreeString(String indent);
}
